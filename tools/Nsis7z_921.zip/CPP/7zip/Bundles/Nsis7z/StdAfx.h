// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../../Common/MyWindows.h"
#include "../../../Common/NewHandler.h"

#endif
